#!/usr/bin/env python
import pika
import sys
from flask import Flask, request, abort, render_template, jsonify, Response
import sqlite3
import requests
import re
import datetime
import json
import docker
import time
import uuid
import os
import subprocess
from kazoo.client import KazooClient
from kazoo.client import EventType
import logging
logging.basicConfig()
app = Flask(__name__)
client = docker.from_env()
presentSlaves = 1
countofWorker=1
crashslave=False
count = 0
readReq = False  # true: writereq false : readReq



#create master

#create slave
def createSlaves(slaves):
    client = docker.from_env()
    global Slavesactive
    global workerCount
    workerCount+=1
    print(slaves, "slaves to create")
    Slavesactive = Slavesactive+slaves
    for i in range(slaves):
        containerlist = client.containers.run(
            "slave", detach=True, network="ubuntu_network",environment=["workerUniqueId="+str(workerCount)])
        run = client.containers.list()


class RpcClient(object):
    def __init__(self, readReq, responseQueueName, messageQueueName):
        self.readRequest = readReq
        self.messageQueue = messageQueueName
        self.responseQueueName = responseQueueName
        self.connection = pika.BlockingConnection(
            pika.ConnectionParameters(host='rmq'))

        self.channel = self.connection.channel()

        result = self.channel.queue_declare(queue="",exclusive=True,durable=True)
        self.callback_queue = result.method.queue
        print('\n\ncallbackQueue :'+self.callback_queue+'\n\n')
        self.channel.basic_consume(
            queue=self.callback_queue,
            on_message_callback=self.on_response,

            )

    def on_response(self, ch, method, props, body):
        print("In on_response")
        print(self.corr_id, "actual correlation Id")
        print(props.correlation_id, "returned Corelation_id")
        if self.corr_id == props.correlation_id:
            self.response = json.loads(body)
        ch.basic_ack(delivery_tag=method.delivery_tag)

    def call(self, data):
        print("pushing data into queue . .. ")
        self.response = None
        self.corr_id = str(uuid.uuid4())
        self.channel.basic_publish(
            exchange='',
            routing_key=self.messageQueue,
            properties=pika.BasicProperties(
                reply_to=self.callback_queue,
                correlation_id=self.corr_id,
                delivery_mode=2,  # make message persistent
            ),
            body=json.dumps(data))
        print("pushing data into queue success, Waiting for response..")

        while self.response is None:
            self.connection.process_data_events()
        print('\n\n response :', self.response)
        self.connection.close()
        return self.response



#clear database
@app.route('/api/v1/db/clear',methods=['POST'])
def clear_db():
    Url="127.0.0.1"
    user_del =     sqlquery1={"table":"user","query":"clear","isDelete":"False","isClear":"True"}
    ride_del =     sqlquery1={"table":"ride","query":"clear","isDelete":"False","isClear":"True"}
    uride_del =     sqlquery1={"table":"userride","query":"clear","isDelete":"False","isClear":"True"}
    udetails = {"table":"userdetails","query":"clear","isDelete":"False","isClear":"True"}
    try:
        requests.post(url=Url+'/api/vs1/db/write',json=user_del)
        requests.post(url=Url+'/api/v1/db/write',json=ride_del)
        requests.post(url=Url+'/api/v1/db/write',json=uride_del)
        requests.post(url=Url+'/api/v1/db/write',json=udetails)
    except Exception as e:
        print('Db Clear failed')

    return Response(status=200)


@app.route('/api/v1/db/read',methods=["POST"])
def readDB():
    print("\n read Request..\n")
    result={}
    data = request.get_json()
    print(data,"Request Data for Read")
    readRpc = RpcClient(True,"responseQ","readQ")
    Responseofread=readRpc.call(data)
    print('\n\n Read response :',Responseofread)
    return jsonify(Responseofread)


@app.route('/api/v1/db/write',methods=["POST"])
def WriteToDB():
    print("\n Write Request..\n")
    result={}
    data = request.get_json()
    print(data,"Request Data for Write")
    #time.sleep(5)
    readRpc = RpcClient(False,"ResponsewriteQ","writeQ")
    WriteResponse=readRpc.call(data)
    print('\n\n Write Response :',WriteResponse)
    return jsonify(WriteResponse)


if __name__ == '__main__':
    app.debug=True
    app.run(host="0.0.0.0",port=80)
